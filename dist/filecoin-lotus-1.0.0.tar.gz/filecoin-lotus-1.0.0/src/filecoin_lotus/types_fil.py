from typing import NewType

RPCEndpoint = NewType("RPCEndpoint", str)